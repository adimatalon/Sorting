import java.util.Random;

import Plotter.Plotter;


public class Sorting {


	final static int BUBBLE_VS_QUICK_LENGTH = 12;
	final static int MERGE_VS_QUICK_LENGTH = 15;
	final static int BUBBLE_VS_QUICK_SORTED_LENGTH = 12;
	final static int ARBITRARY_VS_MEDIAN_LENGTH = 16;
	final static double T = 600.0;
	/**
	 * Sorts a given array using the quick sort algorithm.
	 * At each stage the pivot is chosen to be the rightmost element of the subarray.
	 * 
	 * Should run in average complexity of O(nlog(n)), and worst case complexity of O(n^2)
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void quickSortArbitraryPivot(double[] arr){
		int p=0;
		int r=arr.length-1;
		quickSort(arr,p,r);
	}

	public static void quickSort(double []arr,int p,int r) {
		if (p < r) {
			int q = partition(arr, p, r);
			quickSort(arr, p, q - 1);
			quickSort(arr, q + 1, r);
		}
	}

	public static int partition(double []arr,int p,int r) {
	 	double x= arr[r];
	 	int i=p-1;
	 	for(int j=p; j<r ; j++){
	 		if(arr[j]<=x) {
                i = i + 1;
                swap(arr,i,j);
            }
			}
			swap(arr,i+1,r);
		return i+1;
	}
	
	/**
	 * Sorts a given array using the quick sort algorithm.
	 * At each stage the pivot is chosen in the following way:
	 * Choose 3 random elements from the array, the pivot is the median of the 3 elements.
	 *
	 * Should run in average complexity of O(nlog(n)), and worst case complexity of O(n^2)
	 *
	 * @param arr - the array to be sorted
	 */
	public static void quickSortMedianPivot(double[] arr){
		int p=0;
		int r=arr.length-1;
		quickSortMedianPivot2(arr,p,r);
	}
	public static void quickSortMedianPivot2(double[] arr,int p,int r){
        if (p  < r) {
            int q  = chooseMedian(arr, p, r);
            quickSortMedianPivot2(arr,p,q-1);
            quickSortMedianPivot2(arr,q+1,r);
        }

}
        public static int chooseMedian(double[] arr,int p,int r) {

            int x = p + (int)(Math.random()*(1+r-p));
            int y = p + (int)(Math.random()*(1+r-p));
            int m = p + (int)(Math.random()*(1+r-p));
            double c = arr[m];
            double b =arr[x];
            double a =arr[y];
            int median;
            if(arr[m]<arr[x] && arr[m]>arr[y] || arr[m]>arr[x] && arr[m]<arr[y]) {
                median = m;
            }
            if(arr[x]<arr[y] && arr[x]>arr[m] || arr[x]>arr[y] && arr[x]<arr[m]) {
                median = x;
            }else median=y;
            int q  = partitionMedian(arr,p,r,median);
           return q;
        }



	public static int partitionMedian(double[] arr,int p,int r,int median) {
	    swap(arr,r,median);
        median=r;
        int j=p;
        double x = arr[median];
        for(int k=p; k<median ; k++){
            if(arr[k]<x) {
                swap(arr,k,j);
                j++;
            }
        }
        swap(arr,median,j);
        return j;
    }

    public static void swap(double[] arr,int i,int j) {
        double temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

	/**
	 * Sorts a given array using the merge sort algorithm.
	 * 
	 * Should run in complexity O(nlog(n)) in the worst case.
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void mergeSort(double[] arr){
		int r = arr.length-1;
		int p=0;
		mergeSort2(arr,p,r);


        }

	public static void mergeSort2(double[] arr,int p,int r){
		if (p<r) {
			int q = (p + r) / 2;
			mergeSort2(arr, q + 1, r);
			mergeSort2(arr, p, q);
			merge(arr, p, q, r);
		}
		}

	public static void merge(double[] arr,int p,int q,int r) {
        int n1=q-p+1;
        int n2=r-q;
        double [] L = new double[n1+1];
        double [] R = new double[n2+1];


        for(int i=0; i<n1; i++) {
            L[i] = arr[i+p];
        }
        for(int j=0; j<n2; j++) {
            R[j] = arr[j + q + 1];
        }
        L[n1]=Double.MAX_VALUE;
        R[n2]=Double.MAX_VALUE;

        int j=0; int i=0;

        for(int k=p; k<=r ;k++){
            if (L[i] <= R[j])
            {
                arr[k] = L[i];
                i++;
            }
            else
            {
                arr[k] = R[j];
                j++;
            }
        }
    }


        /**
         * Sorts a given array using bubble sort.
         * If at any time the algorithm recognizes no more inversions are needed it should stop.
         *
         * The algorithm should run in complexity O(n^2) in the worst case.
         * The algorithm should run in complexity O(n) in the best case.
         *
         * @param arr - the array to be sorted
         */
        public static void bubbleSort ( double[] arr){
        	int n= arr.length - 1;
        	bubbleSort2(arr,n);

        }
	public static void bubbleSort2 ( double[] arr,int n) {
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < n-i; j++) {
				if (arr[j - 1] > arr[j]) {
				    swap(arr,j,j-1);
				}
			}
		}
	}

	public static void main(String[] args) {

		bubbleVsQuick();
		mergeVsQuick();
		bubbleVsQuickOnSortedArray();
		arbitraryPivotVsMedianPivot();
	}
	
	/**
	 * Compares the selection sort algorithm against quick sort on random arrays
	 */
	public static void bubbleVsQuick(){
		double[] quickTimes = new double[BUBBLE_VS_QUICK_LENGTH];
		double[] bubbleTimes = new double[BUBBLE_VS_QUICK_LENGTH];
		long startTime, endTime;
		Random r = new Random();
		for (int i = 0; i < BUBBLE_VS_QUICK_LENGTH; i++) {
			long sumQuick = 0;
			long sumSelection = 0;
			for(int k = 0; k < T; k++){
				int size = (int)Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = r.nextGaussian() * 5000;
					b[j] = a[j];
				}
				startTime = System.currentTimeMillis();
				quickSortArbitraryPivot(a);
				endTime = System.currentTimeMillis();
				sumQuick += endTime - startTime;
				startTime = System.currentTimeMillis();
				bubbleSort(b);
				endTime = System.currentTimeMillis();
				sumSelection += endTime - startTime;
			}
			quickTimes[i] = sumQuick/T;
			bubbleTimes[i] = sumSelection/T;
		}
		Plotter.plot("quick sort on random array", quickTimes, "bubble sort on random array", bubbleTimes);
	}

	/**
	 * Compares the merge sort algorithm against quick sort on random arrays
	 */
	public static void mergeVsQuick(){
		double[] quickTimes = new double[MERGE_VS_QUICK_LENGTH];
		double[] mergeTimes = new double[MERGE_VS_QUICK_LENGTH];
		long startTime, endTime;
		Random r = new Random();
		for (int i = 0; i < MERGE_VS_QUICK_LENGTH; i++) {
			long sumQuick = 0;
			long sumMerge = 0;
			for (int k = 0; k < T; k++) {
				int size = (int)Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = r.nextGaussian() * 5000;
					b[j] = a[j];
				}
				startTime = System.currentTimeMillis();
				quickSortArbitraryPivot(a);
				endTime = System.currentTimeMillis();
				sumQuick += endTime - startTime;
				startTime = System.currentTimeMillis();
				mergeSort(b);
				endTime = System.currentTimeMillis();
				sumMerge += endTime - startTime;
			}
			quickTimes[i] = sumQuick/T;
			mergeTimes[i] = sumMerge/T;
		}
		Plotter.plot("quick sort on random array", quickTimes, "merge sort on random array", mergeTimes);
	}

	/**
	 * Compares the merge sort algorithm against quick sort on pre-sorted arrays
	 */
	public static void bubbleVsQuickOnSortedArray(){
		double[] quickTimes = new double[BUBBLE_VS_QUICK_SORTED_LENGTH];
		double[] bubbleTimes = new double[BUBBLE_VS_QUICK_SORTED_LENGTH];
		long startTime, endTime;
		for (int i = 0; i < BUBBLE_VS_QUICK_SORTED_LENGTH; i++) {
			long sumQuick = 0;
			long sumBubble = 0;
			for (int k = 0; k < T; k++) {
				int size = (int)Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = j;
					b[j] = j;
				}
				startTime = System.currentTimeMillis();
				quickSortArbitraryPivot(a);
				endTime = System.currentTimeMillis();
				sumQuick += endTime - startTime;
				startTime = System.currentTimeMillis();
				bubbleSort(b);
				endTime = System.currentTimeMillis();
				sumBubble += endTime - startTime;
			}
			quickTimes[i] = sumQuick/T;
			bubbleTimes[i] = sumBubble/T;
		}
		Plotter.plot("quick sort on sorted array", quickTimes, "bubble sort on sorted array", bubbleTimes);
	}

	/**
	 * Compares the quick sort algorithm once with a choice of an arbitrary pivot and once with a choice of a median pivot
	 */
	public static void arbitraryPivotVsMedianPivot(){
		double[] arbitraryTimes = new double[ARBITRARY_VS_MEDIAN_LENGTH];
		double[] medianTimes = new double[ARBITRARY_VS_MEDIAN_LENGTH];
		long startTime, endTime;
		Random r = new Random();
		for (int i = 0; i < ARBITRARY_VS_MEDIAN_LENGTH; i++) {
			long sumArbitrary = 0;
			long sumMedian = 0;
			for (int k = 0; k < T; k++) {
				int size = (int)Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = r.nextGaussian() * 5000;
					b[j] = a[j];
				}
				startTime = System.currentTimeMillis();
				quickSortArbitraryPivot(a);
				endTime = System.currentTimeMillis();
				sumArbitrary += endTime - startTime;
				startTime = System.currentTimeMillis();
				quickSortMedianPivot(b);
				endTime = System.currentTimeMillis();
				sumMedian += endTime - startTime;
			}
			arbitraryTimes[i] = sumArbitrary/T;
			medianTimes[i] = sumMedian/T;
		}
		Plotter.plot("quick sort with an arbitrary pivot", arbitraryTimes, "quick sort with a median pivot", medianTimes);
	}

}
